package by.bsu.travelagency.entity;

/**
 * Created by Михаил on 2/24/2016.
 */
public abstract class Entity {
}
