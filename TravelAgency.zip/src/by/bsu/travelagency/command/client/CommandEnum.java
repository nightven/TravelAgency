package by.bsu.travelagency.command.client;

import by.bsu.travelagency.command.ActionCommand;
import by.bsu.travelagency.command.LoginCommand;
import by.bsu.travelagency.command.LogoutCommand;

/**
 * Created by Михаил on 2/16/2016.
 */
public enum CommandEnum {
    LOGIN {
        {
            this.command = new LoginCommand();
        }
    },
    LOGOUT {
        {
            this.command = new LogoutCommand();
        }
    };
    ActionCommand command;
    public ActionCommand getCurrentCommand() {
        return command;
    }
}
