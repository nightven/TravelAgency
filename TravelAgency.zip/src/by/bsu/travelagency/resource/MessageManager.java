package by.bsu.travelagency.resource;

import java.util.ResourceBundle;

/**
 * Created by Михаил on 2/16/2016.
 */
public class MessageManager {
    private final static ResourceBundle resourceBundle = ResourceBundle.getBundle("resources.messages");
    // класс извлекает информацию из файла messages.properties
    private MessageManager() { }
    public static String getProperty(String key) {
        return resourceBundle.getString(key);
    }
}
